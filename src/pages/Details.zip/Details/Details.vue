<template>
  <div class="details-calc max-w-screen-lg m-auto pt-8">
    <h2 class="pb-4">Calculation Details</h2>
    <div class="details-wrapper flex justify-around flex-wrap m-auto">
      <div class="details-col">
        <div class="details-block">
          <p class="details-label">
            {{ formatUSD(property_price) }}
          </p>
          <p class="details-count">
            11111
          </p>
        </div>
        <div class="details-block">
          <p class="details-label">
            Down Payment
          </p>
          <p class="details-count">
            $0.00
          </p>
        </div>
        <div class="details-block">
          <p class="details-label">
            Total Loan Amount
          </p>
          <p class="details-count">
            $550,000.00
          </p>
        </div>
        <div class="details-block">
          <p class="details-label">
            Interest Rate
          </p>
          <p class="details-count">
            4.000%
          </p>
        </div>
      </div>
      <div class="details-col">
        <div class="details-block">
          <p class="details-label">
            Principal & Interest
          </p>
          <p class="details-count">
            $2,625.78
          </p>
        </div>
        <div class="details-block">
          <p class="details-label">
            Taxes & HOA
          </p>
          <p class="details-count">
            $0.00
          </p>
        </div>
        <div class="details-block">
          <p class="details-label">
            Hazard Insurance
          </p>
          <p class="details-count">
            $66.67
          </p>
        </div>
        <div class="details-block">
          <p class="details-label">
            Mortgage Insurance
          </p>
          <p class="details-count">
            $0.00
          </p>
        </div>
        <div class="details-block">
          <p class="details-label">
            Monthly Payment
          </p>
          <p class="details-count">
            $2,692.45
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<style lang="sass" scoped>

    .details-col
        max-width: 362px
        flex-basis: 40%

    .details-block
        display: flex
        justify-content: space-between
        padding: 12px 0 13px 0
        color: var(--color-body)
        border-bottom: 1px  dashed var(--color-primary-light)

    .details-block p
        font-size: 18px
        font-weight: 600

</style>

<script>
  export default {
    data() {
      return {
        property_price: 250000,
        down_payment: 8750,
        interest_rate: 4,
        annual_insurance: 10,

      }
    },

    methods:{
      formatUSD: function(number){
        number.toLocaleString('en-US',
          {style: 'currency', currency: 'USD'}
        );
        return(
          new Intl.NumberFormat('en-US',
            { style: 'currency', currency: 'USD' }
          ).format(number)
        )
      }
    }

  }
</script>

